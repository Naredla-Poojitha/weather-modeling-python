# weather_model_hardcoded.py

def quadratic_weather_model(a, b, c, x):
    return a * x**2 + b * x + c

# Hardcoded coefficients and time value
a = 0.5
b = -2.5
c = 30
x = 5

# Calculate the result
y = quadratic_weather_model(a, b, c, x)

# Output the result
print(f"Predicted temperature at time {x} is: {y}")