# weather_model_file_single.py

def quadratic_weather_model(a, b, c, x):
    return a * x**2 + b * x + c

try:
    # Read values from file
    with open("input.txt", "r") as file:
        lines = file.readlines()
        a = float(lines[0].strip())
        b = float(lines[1].strip())
        c = float(lines[2].strip())
        x = float(lines[3].strip())

        # Calculate result
        y = quadratic_weather_model(a, b, c, x)

        # Output result
        print(f"Predicted temperature at time {x} is: {y}")

except FileNotFoundError:
    print("Error: File 'input.txt' not found.")
except (ValueError, IndexError):
    print("Error: File format is incorrect or missing data.")