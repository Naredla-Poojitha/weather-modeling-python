# weather_model_keyboard.py

def quadratic_weather_model(a, b, c, x):
    return a * x**2 + b * x + c

try:
    # Take user input
    a = float(input("Enter coefficient a: "))
    b = float(input("Enter coefficient b: "))
    c = float(input("Enter coefficient c: "))
    x = float(input("Enter time (x): "))

    # Calculate result
    y = quadratic_weather_model(a, b, c, x)

    # Output result
    print(f"Predicted temperature at time {x} is: {y}")

except ValueError:
    print("Error: Please enter valid numeric input.")