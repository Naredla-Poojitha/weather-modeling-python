# weather_model_file_multiple.py

def quadratic_weather_model(a, b, c, x):
    return a * x**2 + b * x + c

try:
    # Open and read each line of the file
    with open("multiple_inputs.txt", "r") as file:
        lines = file.readlines()

        for i, line in enumerate(lines, start=1):
            parts = line.strip().split()
            if len(parts) != 4:
                print(f"Skipping line {i}: Incorrect format")
                continue

            # Parse values
            a = float(parts[0])
            b = float(parts[1])
            c = float(parts[2])
            x = float(parts[3])

            # Calculate and print result
            y = quadratic_weather_model(a, b, c, x)
            print(f"Set {i}: Predicted temperature at time {x} is: {y}")

except FileNotFoundError:
    print("Error: File 'multiple_inputs.txt' not found.")
except ValueError:
    print("Error: One or more values in the file are not valid numbers.")